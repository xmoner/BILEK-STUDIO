import bpy
print('hello blender')