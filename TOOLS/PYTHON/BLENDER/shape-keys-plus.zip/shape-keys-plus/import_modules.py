import bpy
import os
import pathlib

#path = '/Users/lukas/Documents/BILEK-STUDIO/CODE/TOOLS/PYTHON/BLENDER/shape-keys-plus'
#if not os.path.exists(path):

#    os.path.append(path)

#import shape_keys_plus_main as shape_keys

#shape_keys()

